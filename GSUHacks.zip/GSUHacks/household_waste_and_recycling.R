library(dplyr)
main <- read.csv("Nischay_Uppal_FIles/Semester 1/GSUHacks/household-waste-and-recycling-1.csv")
meta <- read.csv("Nischay_Uppal_FIles/Semester 1/GSUHacks/metadata-2.csv")
head(main)
head(meta)

mean(main$HholdWasteRecycledPercentage)
mean(main$HholdWasteCollectedPerPersonKg)

mean_percent_by_GeoName <- tapply(main$HholdWasteRecycledPercentage, main$GeoName, mean)
mean_weight_by_GeoName <- tapply(main$HholdWasteCollectedPerPersonKg, main$GeoName, mean)

mean_percent_by_GeoName
mean_weight_by_GeoName

LinearModel = lm(main$HholdWasteRecycledPercentage~main$HholdWasteCollectedPerPersonKg, data=main)
LinearModel

plot(main$HholdWasteRecycledPercentage~main$HholdWasteCollectedPerPersonKg, data=main)
plot(main$HholdWasteCollectedPerPersonKg, main$HholdWasteRecycledPercentage, pch=16, cex=1.3, col="blue", main = "Percentage Recycled vs Waste Collected Per Person",xlab = "Waste Collected (KG per person)", ylab = "Waste Recycled (% per household)" )

linear_regression <- function(x) {
  return(0.1315 * x-9.9271)
}
abline(LinearModel)

king_county <- read.csv("Nischay_Uppal_FIles/Semester 1/GSUHacks/what-do-i-do-with-recycling-options-in-king-county-1.csv")
head(king_county)

where_it_goes <- function(x) {
  index <- which(grepl(x, king_county$Material.Handled [king_county$Material.Handled != "Pick-up service only"]))
  #print(index)
  result <- paste(king_county$Provider.Name[index], king_county$Provider.Address[index], sep="    ")
  return(result)
}

head(where_it_goes("Monitors"))

percentage_recycled <- read.csv("Nischay_Uppal_FIles/Semester 1/GSUHacks/performance-indicator-ces36-1.csv")
head(percentage_recycled)
subset <- percentage_recycled %>% select(Period, Value)
data.frame(sort(subset$Value, decreasing=T),subset$Period)



#In Canada, 25% of recycled material is contaminated. (materials which can't be recycled are included in recycling. or 1 in 3 pounds)
# https://www.cbc.ca/news/technology/recycling-contamination-1.4606893